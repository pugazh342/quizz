const startBtn = document.querySelector('.start-btn');
const popupInfo = document.querySelector('.popup-info');
const exitBtn = document.querySelector('.close-button');
const main = document.querySelector('.main');
const continueBtn = document.querySelector('.start-button');
const quizSection = document.querySelector('.quiz-section');


startBtn.onclick = () => {
  popupInfo.classList.add('active');
  main.classList.add('active');
};

exitBtn.onclick = () => {
  popupInfo.classList.remove('active');
  main.classList.remove('active');
};

continueBtn.onclick = () => {
    popupInfo.classList.remove('active');
    document.querySelector('.main').classList.add('hide');
    quizSection.classList.add('active');
  };
  
